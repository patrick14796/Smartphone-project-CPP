#include "Phone.h"

Phone::Phone()
{
}
Phone::~Phone()
{
}