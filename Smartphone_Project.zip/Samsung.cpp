#include "Samsung.h"

string Samsung::format()
{
	return string();
}

void Samsung::helloMovie()
{
	string str;
	str = SamsungMovie.playSamsung();
	cout << str << endl;
}

