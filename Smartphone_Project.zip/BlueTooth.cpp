#include "BlueTooth.h"

string BlueTooth::protocol()
{
	return "BlueTooth";
}

string BlueTooth::scan()
{
	return "BlueTooth scanning";
}