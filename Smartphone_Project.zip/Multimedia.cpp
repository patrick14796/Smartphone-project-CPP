#include "Multimedia.h"
Multimedia::Multimedia()
{
}
Multimedia::~Multimedia()
{

}
string Multimedia::type()
{
	return "AudioPlayer,VideoPlayer,Camera";
}
string Multimedia::format()
{
	return string();
}