#include "WireLess.h"

string WireLess::connected()
{
	return "CONNCETED";
}

void WireLess::wirelessProperties()
{
}
