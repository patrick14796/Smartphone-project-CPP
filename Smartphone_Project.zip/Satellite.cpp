#include "Satellite.h"

string Satellite::protocol()
{
	return "Satellite";
}

string Satellite::scan()
{
	return "Satellite scanning";
}
