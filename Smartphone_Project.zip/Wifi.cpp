#include "Wifi.h"

string WiFi::protocol()
{
	return "WiFi";
}

string WiFi::scan()
{
	return "WiFi Scanning";
}