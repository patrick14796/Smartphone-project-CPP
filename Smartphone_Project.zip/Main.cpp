/*
NAME:IVAN BORISENCO
NAME:PATRICK LUGASSY
ID:317366102
ID:319266177
CAMPUS:ASHDOD
*/
#include "CommunicationSimulator.h"

int main()
{
	CommunicationSimulator obj;
	obj.SumilatorRun();
	return 0;
}